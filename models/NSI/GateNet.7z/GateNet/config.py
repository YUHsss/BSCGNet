# coding: utf-8
import os
datasets_root_train =r'E:\data\ORSSD\train/'
datasets_root_test ='/home/zxq/code/coding/saliency_Dataset/DUTS/DUTS-TE'

train_data = os.path.join(datasets_root_train)
test_data = os.path.join(datasets_root_test)


