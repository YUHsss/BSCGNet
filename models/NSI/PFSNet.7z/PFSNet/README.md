# PFSNet

### Saliency maps
[BaiduPan](https://pan.baidu.com/s/1aa-FtfSg1rcgSEeuBk6X1w) code:`3dcn`

### Pretrained model
[Google Drive](https://drive.google.com/file/d/16dZ_D3tlzEGsfh3KIamaxEfts1KA4t7Z/view?usp=sharing)
